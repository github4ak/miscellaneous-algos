public class Sample{
  public static void main(String args[]){
    double x = 5;
    double y;
    y = Math.sqrt(x);
    System.out.println("The square root of x is "+y);
    System.out.println("The first argument is "+args[0]);
}
}