import java.lang.*;
class SquareRoot{
  double test(double x,double g){
    if (closeEnough(x/g,g))
      return g;
    else
      return test(x,betterGuess(x,g));
  }
  
  boolean closeEnough(double a, double b){
  return (Math.abs(a-b) < b*0.001);
  }
  
  double betterGuess(double x, double g){
  return ((g+x/g)/2);
  }
  
}