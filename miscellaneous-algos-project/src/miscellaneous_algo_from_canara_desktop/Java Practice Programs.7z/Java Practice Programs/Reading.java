import java.util.Scanner;
class Reading{
  public static void main(String args[]){
  Scanner sc  = new Scanner(System.in);
  int num = 0;;
  float flo = 0.0f;
  try{
    System.out.println("Enter an integer");
    num = Integer.parseInt(sc.nextLine());
    System.out.println("Enter a float");
    flo = Float.valueOf(sc.nextLine());
  }
  catch(Exception e){}
    System.out.println("The value of int and float are "+num+" and "+flo);
  
  
  }

}