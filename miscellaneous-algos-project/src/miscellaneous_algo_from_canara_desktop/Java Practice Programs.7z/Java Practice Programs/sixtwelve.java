class sixtwelve{
  public static void main(String args[]){
  int i,j,num=1;
  for(i=1;i<20;i++){
    for(j=1;j<i;j++){
     if(num%2==0)
       System.out.print("0"+" ");
     else
       System.out.print("1"+" ");
     num++;
    }
    System.out.println();
  }
  }
}