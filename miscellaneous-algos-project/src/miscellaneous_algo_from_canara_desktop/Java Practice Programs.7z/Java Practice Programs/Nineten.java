class Nineten{
  public static void main(String args[]){
    int a[][] = {{1,2,3},
                   {2,2,4},
                   {5,6,3}};
    
    int b[][] = {{1,2,3},
                   {3,3,4},
                   {6,6,8}};
    
    int c[][] = new int[3][3];
    
    for(int i=0;i<a[0].length;i++){
      for(int j=0;j<b[0].length;j++){
        for(int k=0;k<b[0].length;k++){
         c[i][j] += a[i][k]*b[k][j];
        }
      }
    }
    
    System.out.println("The product array is ");
    
    for(int x = 0; x < 3;x++){
      for(int y = 0; y < 3;y++){
        System.out.print(c[x][y]+" ");
      }
      System.out.println();
    }
  }
}