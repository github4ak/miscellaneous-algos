import java.util.Scanner;
class sevensix{
  public static void main(String args[]){
   Scanner sc = new Scanner(System.in);
   System.out.println("Enter an number");
   int num = Integer.parseInt(sc.nextLine());
   long fact = 1;
   for(int i=num;i>=1;i--){
     fact*=i;
   }
   System.out.println(fact);
  }
}