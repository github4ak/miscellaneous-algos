import java.lang.*;
class NthRoot{
  int n;
  NthRoot(int n){
    this.n = n;
  }
  double f(double w, double g){
    return (Math.pow(g,n) - w);
  }
  
  double fPrime(double g){
    return (n*Math.pow(g,n-1));
  }
  
  boolean closeEnough(double a, double b){
  return (Math.abs(a-b) < Math.abs(b*0.001));
  }
  
  double newGuess(double w,double g){
    return g - f(w,g)/fPrime(g);
  }
  
  double findRoot(double w, double g){
    if (closeEnough(newGuess(w,g),g))
      return newGuess(w,g);
    else
      return findRoot(w,newGuess(w,g));
  }
}