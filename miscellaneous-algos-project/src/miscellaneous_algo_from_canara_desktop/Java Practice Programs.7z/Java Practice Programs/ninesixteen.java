class ninesixteen{
  public static void main(String args[]){
    String str = "string";
    char arr[] = str.toCharArray();
    for(int i=0;i<arr.length;i++){
      for(int j=i+1;j<arr.length;j++){
        if(arr[i]>arr[j]){
          char temp = arr[j];
          arr[j] = arr[i];
          arr[i] = temp;
        }
      }
    }
    System.out.println("The sorted string is "+new String(arr));
    
  }
}