package ebalaguruswamy{
  class TestFirst{
    int radius = 10;
  }
}