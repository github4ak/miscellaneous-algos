class TestSecond{
  int radius = 12;
}