import java.lang.Exception;
class NoMatchException extends Exception{
  NoMatchException(String message){
    super(message);
  }
}
class TestMyException{
  public static void main(String[] args){
  String test = "Bangladesh";
  try{
    if(!test.equals("India"))
      throw new NoMatchException("Not India");
  }
  catch(NoMatchException e){
    System.out.println("Caught my exception");
    System.out.println(e.getMessage());
  }
  finally{
    System.out.println("The test string was"+test);
  }
  }

}