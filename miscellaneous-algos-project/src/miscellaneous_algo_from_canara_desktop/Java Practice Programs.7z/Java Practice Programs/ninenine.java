class Test{
  public static void main (String args[]){
    int a[] = {1,2,3,8,9};
    int b[] = {1,2,3,4,5};
    int c[] = new int[a.length+b.length];
    int i,j,k;
    i = j = k = 0;
    while(i<a.length && j<b.length){
      if(a[i] < b[j]){
        c[k] = a[i];
        k++;
        i++;
      }
      else{
        c[k] = b[j];
        k++;
        j++;
      }
    }
    
    // Put the remaining elements as it is
    
    if(i!=a.length){
      while(i!=a.length){
        c[k] = a[i];
        k++;
        i++;
      }
     }
    else{
      while(j!=b.length){
        c[k] = b[j];
        k++;
        j++;
      }
    }
  
  
  System.out.println("The merged array is ");
  for(int x = 0; x<c.length;x++){
    System.out.print(c[x]+" ");
  }
  }
}  