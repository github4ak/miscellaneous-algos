import java.util.Scanner;
class fourthirteen{
public static void main(String args[]){
  Scanner sc = new Scanner(System.in);
  System.out.println("Enter an integer");
  int n = Integer.parseInt(sc.nextLine());
  double hsum = 0;
  for(int i=1;i<=n;i++){
  hsum+=(double)1/i;
  }
  
 System.out.println("The harmonic sum is "+hsum);
}
}