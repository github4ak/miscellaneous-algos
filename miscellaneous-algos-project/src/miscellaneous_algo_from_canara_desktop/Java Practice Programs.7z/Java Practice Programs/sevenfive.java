import java.util.Scanner;
class sevenfive{
  public static void main(String args[]){
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter a number");
    int num = Integer.parseInt(sc.nextLine());
    String revstr;
    while(num/10!=num){
      System.out.print(num%10);
      num/=10;
    }
  }
}