class Rect implements Area{
  public float compute(float x,float y){
    return x*y;
  }
}