import java.util.*;
class ninetwelve{
  public static void main(String args[]){
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter the string you want to trim");
    String trim = sc.nextLine();
    System.out.println("Enter the element position you want to deleted");
    int m = sc.nextInt();
    System.out.println("The trimmed string is "+delete(trim,m));
  }
  static String delete(String str, int m){
    String substrBefore = str.substring(0,m);
    String substrAfter = str.substring(m+1);
    return substrBefore+substrAfter;
  }
}