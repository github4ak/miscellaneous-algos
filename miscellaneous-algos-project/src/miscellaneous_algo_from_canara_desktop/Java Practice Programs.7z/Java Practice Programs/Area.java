interface Area{
  final float PI = 3.14F;
  float compute(float x,float y);
}
