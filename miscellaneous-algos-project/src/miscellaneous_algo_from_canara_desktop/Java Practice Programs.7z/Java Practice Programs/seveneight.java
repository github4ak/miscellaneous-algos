class seveneight{
  public static void main(String args[]){
    int n = 8;
    int prev_1 = 1;
    int prev = prev_1;
    int old_prev;
    System.out.print(prev+" "+prev_1+" ");
    for(int i=0;i<n-2;i++){
     System.out.print(prev+prev_1+" ");
     old_prev = prev_1;
     prev_1 = prev;
     prev = prev + old_prev;
    }
  }
}