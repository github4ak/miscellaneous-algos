class InterfaceTest{
  public static void main(String args[]){
    Rect rect = new Rect();
    Area area;
    area = rect;
    System.out.println("The area of the rectange is "+rect.compute(10,10));
  }

}