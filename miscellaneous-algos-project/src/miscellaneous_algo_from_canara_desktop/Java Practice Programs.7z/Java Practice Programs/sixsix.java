public class sixsix{
  public static void main(String args[]){
   int iter = 100;
   int count = 0,sum = 0;
   while(iter<200){
     if(iter%7==0){
     count+=1;
     sum+=iter;
     }
     iter+=1;
   }
   
   System.out.println("The number of integers divisible by 7 is "+count+" and their sum is "+sum);
  }
}