class Room {
float length;
float breadth;

void getData(float a, float b){
  length = a;
  breadth = b;
}
}