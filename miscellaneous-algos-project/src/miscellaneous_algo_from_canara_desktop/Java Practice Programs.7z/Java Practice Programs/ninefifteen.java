import java.util.*;
import java.util.regex.*;
class ninefifteen{
  public static void main(String args[]){
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter line");
    String input = sc.nextLine();
    System.out.println("Enter word you want to search");
    String check = sc.nextLine();
    System.out.println("The number of occurences of "+check+" is "+wordCount(input,check));
  }
  
  static int wordCount(String input,String check){
    int occurences = 0;
    String str[] = input.split(" ");
    for(String s:str){
      if(s.equals(check)){
        occurences++;
      }
    }
    return occurences;
  }
}