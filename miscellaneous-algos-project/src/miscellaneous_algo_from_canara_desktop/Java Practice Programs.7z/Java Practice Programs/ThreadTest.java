class A extends Thread{
  public void run(){
    for(int i=1 ; i<=5 ; i++){
      if(i==1)
        yield();
      System.out.println("From Thread A: i="+i);
    }
    System.out.println("Exit from Thread A");
  }
}
class B extends Thread{
  public void run(){
    for(int i=1 ; i<=5 ; i++){
      if(i==4)
        stop();
      System.out.println("From Thread A: i="+i);
    }
    System.out.println("Exit from Thread A");
  }
}
class C extends Thread{
  public void run(){
    for(int i=1 ; i<=5 ; i++){
      if(i==3)
        try{
        sleep(1000);
      }
      catch(Exception e){
      e.printStackTrace();
      }
      System.out.println("From Thread A: i="+i);
    }
    System.out.println("Exit from Thread A");
  }
}
public class ThreadTest{
  public static void main(String args[]){
  System.out.println("Start Thread A");
  new A().start();
  System.out.println("Start Thread B");
  new B().start();
  System.out.println("Start Thread C");
  new C().start();
  System.out.println("Exit from main() thread");  
  }
}

