import java.util.Scanner;
public class Fourfourteen {
  
  
  public static void main(String[] args) { 
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter a decimal number");
    double dnum = Double.valueOf(sc.nextLine());
    int ddigits = String.valueOf(dnum).split("\\.")[1].length();
    double mul = java.lang.Math.pow(10,ddigits);
    System.out.println((int)(dnum*mul));
    
  }
}
