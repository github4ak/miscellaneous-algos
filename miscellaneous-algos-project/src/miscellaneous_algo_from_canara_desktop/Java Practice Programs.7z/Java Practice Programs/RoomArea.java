class RoomArea{
  public static void main(String args[]){
    Room r1 = new Room();
    r1.getData(14,10);
    System.out.println("The area of room "+r1.length*r1.breadth);
    
  }
}